param([string]$AndroidSdk="$env:LOCALAPPDATA/Android/Sdk",[string]$Jdk=$env:JAVA_HOME)
$ErrorActionPreference='Stop'
$projectRoot=Split-Path $PSScriptRoot -Parent
if(!$Jdk){$candidate=Join-Path $projectRoot '../../work/jdk21';if(Test-Path -LiteralPath $candidate){$Jdk=(Get-ChildItem -LiteralPath $candidate -Directory | Select-Object -First 1).FullName}}
if(!$Jdk){throw 'Set JAVA_HOME to JDK 21 (or pass -Jdk).'}
$env:JAVA_HOME=$Jdk
$env:ANDROID_HOME=$AndroidSdk
$stage=Join-Path $projectRoot 'android-build/assets16'
New-Item -ItemType Directory -Force -Path $stage | Out-Null
Get-ChildItem -LiteralPath (Join-Path $projectRoot 'dist') -File | Where-Object Extension -In '.html','.js','.css','.webmanifest' | Copy-Item -Destination $stage -Force
foreach($folder in @('icons','audio')){ $target=Join-Path $stage $folder;New-Item -ItemType Directory -Force -Path $target | Out-Null;Get-ChildItem -LiteralPath (Join-Path $projectRoot "dist/$folder") -File | Copy-Item -Destination $target -Force }
Copy-Item -LiteralPath (Join-Path $projectRoot 'dist/icons/shams-app.png') -Destination (Join-Path $PSScriptRoot 'res/drawable/shams_icon.png') -Force
$env:SHAMS_APK_STORE_PASS=[IO.File]::ReadAllText((Join-Path $projectRoot 'private-data/android-signing-password.txt'))
try {
 & (Join-Path $PSScriptRoot 'gradlew.ps1') --no-daemon assembleRelease bundleRelease
 if($LASTEXITCODE -ne 0){throw 'Android Gradle build failed'}
 $apk=Join-Path (Split-Path $projectRoot -Parent) 'SHAMS-1.8.0.apk'
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'build/outputs/apk/release/ShamsAndroid-release.apk') -Destination $apk -Force
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'build/outputs/bundle/release/ShamsAndroid-release.aab') -Destination (Join-Path (Split-Path $projectRoot -Parent) 'SHAMS-1.8.0.aab') -Force
 & (Join-Path $Jdk 'bin/java.exe') -jar (Join-Path $AndroidSdk 'build-tools/35.0.0/lib/apksigner.jar') verify --verbose $apk
 if($LASTEXITCODE -ne 0){throw 'APK signature verification failed'}
 Write-Output "APK: $apk"
}finally{Remove-Item Env:SHAMS_APK_STORE_PASS}
