package app.shams.mobile;

import android.app.Activity;
import android.view.View;
import android.widget.FrameLayout;
import android.util.Log;
import com.google.android.gms.ads.*;
import com.google.android.ump.*;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;

/** Native layout reserves real banner height; no overlay and no client premium flag. */
final class BannerController {
 private final Activity activity;private final FrameLayout slot;
 private final ConsentInformation consent;
 private AdView ad;private boolean initialized=false,consentStarted=false,closed=false,allowed=false;
 private String currentToken="",currentRoute="";private long verifiedAt=0;private int generation=0;
 BannerController(Activity a,FrameLayout parent){activity=a;slot=parent;slot.setVisibility(View.GONE);consent=UserMessagingPlatform.getConsentInformation(a);slot.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{if(ad!=null&&r-l!=or-ol){destroyAd();show();}});}
 void recheck(String route,String token){verifiedAt=0;update(route,token);}
 void pause(){if(ad!=null)ad.pause();}
 void resume(){if(ad!=null)ad.resume();}
 private boolean safeRoute(){return "home".equals(currentRoute)||"more".equals(currentRoute)||"themes".equals(currentRoute);}
 void update(String route,String token){
  if(closed||"off".equals(BuildConfig.ADS_MODE))return;
  currentRoute=route==null?"":route;String next=token==null?"":token;
  if(!safeRoute()){destroyAd();}
  if(!next.equals(currentToken)||System.currentTimeMillis()-verifiedAt>60000){
   currentToken=next;verifiedAt=System.currentTimeMillis();allowed=false;destroyAd();final int version=++generation;
   if(next.isEmpty()){allowed=true;beginConsent();return;}
   if(next.length()>16000)return;
   new Thread(()->{boolean free=false;HttpURLConnection conn=null;try{
    conn=(HttpURLConnection)new URL("https://ayaiddowrabrdltrqysn.supabase.co/rest/v1/rpc/shams_premium_status").openConnection();conn.setRequestMethod("POST");conn.setConnectTimeout(10000);conn.setReadTimeout(10000);conn.setRequestProperty("apikey","sb_publishable_6Px648Ez-hZZYc2vD-JXkQ_M4iuRhLR");conn.setRequestProperty("Authorization","Bearer "+next);conn.setRequestProperty("Content-Type","application/json");conn.setDoOutput(true);try(java.io.OutputStream out=conn.getOutputStream()){out.write("{}".getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    if(conn.getResponseCode()==200){String text;try(java.io.InputStream in=conn.getInputStream()){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[4096];int count;while((count=in.read(buffer))!=-1){if(out.size()+count>64000)throw new java.io.IOException();out.write(buffer,0,count);}text=out.toString("UTF-8");}JSONObject data=new JSONObject(text);free=data.has("premium")&&!data.getBoolean("premium");}
   }catch(Exception e){Log.w("SHAMS-Ads","Entitlement check unavailable; banner hidden");}finally{if(conn!=null)conn.disconnect();}
   final boolean result=free;activity.runOnUiThread(()->{if(closed||version!=generation)return;allowed=result;if(allowed)beginConsent();else destroyAd();});},"shams-ad-entitlement").start();
  }else if(allowed)beginConsent();
 }
 private void beginConsent(){if(closed||!allowed||!safeRoute())return;if(consentStarted){if(consent.canRequestAds())initialize();return;}consentStarted=true;
  consent.requestConsentInfoUpdate(activity,new ConsentRequestParameters.Builder().build(),()->UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity,error->{if(error!=null)Log.w("SHAMS-Ads","Consent form: "+error.getErrorCode());if(consent.canRequestAds())initialize();}),error->{Log.w("SHAMS-Ads","Consent update: "+error.getErrorCode());if(consent.canRequestAds())initialize();});
 }
 private void initialize(){if(closed||!allowed||!safeRoute()||!consent.canRequestAds())return;if(initialized){show();return;}initialized=true;MobileAds.initialize(activity,status->activity.runOnUiThread(this::show));}
 private void show(){if(closed||!initialized||!allowed||!safeRoute()||!consent.canRequestAds()||ad!=null)return;
  int width=((android.view.View)slot.getParent()).getWidth();if(width<=0){slot.post(()->{if(((android.view.View)slot.getParent()).getWidth()>0)show();});return;}
  ad=new AdView(activity);final AdView requested=ad;ad.setAdUnitId(BuildConfig.BANNER_ID);ad.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity,Math.max(1,(int)(width/activity.getResources().getDisplayMetrics().density))));slot.addView(ad,new FrameLayout.LayoutParams(-1,-2));
  ad.setAdListener(new AdListener(){@Override public void onAdLoaded(){if(ad==requested&&allowed&&safeRoute()&&!closed){slot.setVisibility(View.VISIBLE);Log.i("SHAMS-Ads","Banner loaded");}else if(ad==requested)destroyAd();}@Override public void onAdFailedToLoad(LoadAdError error){if(ad==requested)destroyAd();Log.w("SHAMS-Ads","Banner error code="+error.getCode()+" domain="+error.getDomain());}});
  ad.loadAd(new AdRequest.Builder().build());
 }
 void privacy(){if("off".equals(BuildConfig.ADS_MODE)||closed)return;destroyAd();if(consent.getPrivacyOptionsRequirementStatus()==ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED)UserMessagingPlatform.showPrivacyOptionsForm(activity,error->{if(consent.canRequestAds())initialize();});else beginConsent();}
 private void destroyAd(){if(ad!=null){ad.destroy();slot.removeView(ad);ad=null;}slot.setVisibility(View.GONE);}
 void close(){closed=true;generation++;destroyAd();}
}
