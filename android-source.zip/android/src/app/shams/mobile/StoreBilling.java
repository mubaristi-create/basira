package app.shams.mobile;
import android.app.Activity;
import com.android.billingclient.api.*;
import org.json.*;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Official store sheet only. Entitlement is never granted in native/client code. */
final class StoreBilling implements PurchasesUpdatedListener {
 static final String PRODUCT="shams_premium_yearly";
 private final Activity activity;private final BillingClient client;private final java.util.function.Consumer<String> callback;
 private ProductDetails detail;private String offerToken;private String account;private String basePlan;
 StoreBilling(Activity a,java.util.function.Consumer<String> output){activity=a;callback=output;client=BillingClient.newBuilder(a).setListener(this).enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build()).enableAutoServiceReconnection().build();}
 void emit(JSONObject obj){callback.accept(obj.toString());}
 void message(String type,String value){try{emit(new JSONObject().put("type",type).put("message",value));}catch(Exception ignored){}}
 void connect(Runnable ready){if(client.isReady()){ready.run();return;}client.startConnection(new BillingClientStateListener(){public void onBillingSetupFinished(BillingResult result){if(result.getResponseCode()==BillingClient.BillingResponseCode.OK)ready.run();else message("unavailable",String.valueOf(result.getResponseCode()));}public void onBillingServiceDisconnected(){message("unavailable","disconnected");}});}
 void details(String plan){if(plan==null||!plan.matches("[a-z0-9][a-z0-9-]{0,62}")){message("unavailable","base-plan-required");return;}basePlan=plan;connect(()->{query(false);recover();});}
 private void query(boolean launch){
  QueryProductDetailsParams.Product product=QueryProductDetailsParams.Product.newBuilder().setProductId(PRODUCT).setProductType(BillingClient.ProductType.SUBS).build();
  client.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(Collections.singletonList(product)).build(),(result,products)->{
   detail=null;offerToken=null;if(result.getResponseCode()==BillingClient.BillingResponseCode.OK)for(ProductDetails p:products.getProductDetailsList())if(PRODUCT.equals(p.getProductId())&&p.getSubscriptionOfferDetails()!=null)for(ProductDetails.SubscriptionOfferDetails offer:p.getSubscriptionOfferDetails()){
    if(offer.getOfferId()!=null||!offer.getBasePlanId().equals(basePlan))continue;List<ProductDetails.PricingPhase> phases=offer.getPricingPhases().getPricingPhaseList();if(phases.isEmpty())continue;ProductDetails.PricingPhase phase=phases.get(phases.size()-1);
    if(!"P1Y".equals(phase.getBillingPeriod())||phase.getRecurrenceMode()!=ProductDetails.RecurrenceMode.INFINITE_RECURRING)continue;detail=p;offerToken=offer.getOfferToken();try{emit(new JSONObject().put("type","product").put("checkout",launch).put("id",PRODUCT).put("value",String.valueOf(phase.getPriceAmountMicros()/1000000.0)).put("currency",phase.getPriceCurrencyCode()).put("formatted",phase.getFormattedPrice()));}catch(Exception ignored){}break;
   }
   if(detail==null){message("unavailable","product-not-configured");return;}if(launch)activity.runOnUiThread(()->launch());
  });
 }
 void buy(String user){if(!validUser(user)||basePlan==null){message("error","account-required");return;}account=user;connect(()->query(true));}
 private static boolean validUser(String user){return user!=null&&user.matches("[0-9a-fA-F-]{36}");}
 static String accountHash(String uid){try{byte[] bytes=MessageDigest.getInstance("SHA-256").digest(uid.getBytes(StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format("%02x",b));return s.toString();}catch(Exception e){throw new IllegalStateException(e);}}
 private void launch(){BillingFlowParams.ProductDetailsParams p=BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(detail).setOfferToken(offerToken).build();BillingResult r=client.launchBillingFlow(activity,BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(p)).setObfuscatedAccountId(accountHash(account)).build());if(r.getResponseCode()!=BillingClient.BillingResponseCode.OK)message("error",String.valueOf(r.getResponseCode()));}
 public void onPurchasesUpdated(BillingResult result,List<Purchase> purchases){if(result.getResponseCode()==BillingClient.BillingResponseCode.USER_CANCELED){message("canceled","");return;}if(result.getResponseCode()!=BillingClient.BillingResponseCode.OK){message("error",String.valueOf(result.getResponseCode()));return;}send(purchases);}
 private void send(List<Purchase> purchases){boolean found=false;if(purchases!=null)for(Purchase p:purchases)if(p.getProducts().contains(PRODUCT)){found=true;if(p.getPurchaseState()!=Purchase.PurchaseState.PURCHASED){message("pending","");continue;}try{emit(new JSONObject().put("type","purchase").put("store","google").put("token",p.getPurchaseToken()));}catch(Exception ignored){}}if(!found)message("none","");}
 void restore(){connect(()->client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build(),(r,list)->{if(r.getResponseCode()==BillingClient.BillingResponseCode.OK)send(list);else message("error",String.valueOf(r.getResponseCode()));}));}
 private void recover(){client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build(),(r,list)->{if(r.getResponseCode()!=BillingClient.BillingResponseCode.OK)return;List<Purchase> matching=new ArrayList<>();for(Purchase p:list)if(p.getProducts().contains(PRODUCT))matching.add(p);if(!matching.isEmpty())send(matching);});}
 void close(){client.endConnection();}
}
