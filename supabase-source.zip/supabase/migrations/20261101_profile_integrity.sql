begin;
insert into public.shams_profiles(id,email,display_name,created_at,last_sign_in_at) select id,coalesce(email,''),left(coalesce(raw_user_meta_data->>'display_name',''),80),created_at,last_sign_in_at from auth.users on conflict(id) do nothing;
insert into public.shams_events(user_id,kind,created_at) select p.id,'registered',p.created_at from public.shams_profiles p where not exists(select 1 from public.shams_events e where e.user_id=p.id and e.kind='registered');
create or replace function public.shams_claim_admin() returns boolean language plpgsql security definer set search_path='' as $$declare u auth.users;begin
select * into u from auth.users where id=auth.uid();if u.email_confirmed_at is null or not exists(select 1 from shams_private.approved_admins where email=lower(u.email)) or not public.shams_is_active() then return false;end if;
insert into shams_private.admins values(u.id) on conflict do nothing;return public.shams_is_admin();end$$;
create or replace function public.shams_admin_content(p_id uuid,p_kind text,p_payload jsonb,p_published boolean) returns uuid language plpgsql security definer set search_path='' as $$declare result uuid;begin
 if not public.shams_is_admin() then raise exception 'Admin required';end if;
 if p_kind not in ('dua','announcement') or length(coalesce(p_payload->>'title','')) not between 1 and 160 or length(coalesce(p_payload->>'body','')) not between 1 and 12000 then raise exception 'Valid title/body required';end if;
 if p_kind='dua' and p_published and (coalesce(p_payload->>'source','') !~ '^https://' or coalesce(p_payload->>'reviewed','false')<>'true') then raise exception 'Reviewed source required';end if;
 insert into public.shams_content(id,kind,payload,published,updated_by) values(coalesce(p_id,gen_random_uuid()),p_kind,p_payload,p_published,auth.uid()) on conflict(id) do update set kind=excluded.kind,payload=excluded.payload,published=excluded.published,updated_by=excluded.updated_by,updated_at=now() returning id into result;
 insert into public.shams_admin_audit(actor,action,target,details) values(auth.uid(),'content_saved',result::text,jsonb_build_object('kind',p_kind,'published',p_published));return result;end$$;
commit;
