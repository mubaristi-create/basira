param([string]$AndroidSdk="$env:LOCALAPPDATA/Android/Sdk",[string]$Jdk=$env:JAVA_HOME)
& (Join-Path $PSScriptRoot 'build-store.ps1') -AndroidSdk $AndroidSdk -Jdk $Jdk
exit $LASTEXITCODE
