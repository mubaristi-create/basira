param([Parameter(ValueFromRemainingArguments=$true)][string[]]$GradleArgs)
$ErrorActionPreference='Stop'
$javaExe=if($env:JAVA_HOME){Join-Path $env:JAVA_HOME 'bin/java.exe'}else{'C:/Program Files/Android/Android Studio/jbr/bin/java.exe'}
$cacheDir=Join-Path (Split-Path $PSScriptRoot -Parent) 'android-gradle-cache'
$tempRoot=Join-Path (Split-Path $PSScriptRoot -Parent) 'android-build/gradle-tmp'
New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
& $javaExe '-Dorg.gradle.appname=gradlew' '-classpath' (Join-Path $PSScriptRoot 'gradle/wrapper/gradle-wrapper.jar') 'org.gradle.wrapper.GradleWrapperMain' '--gradle-user-home' $cacheDir '-p' $PSScriptRoot "-Dorg.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8 -Djava.io.tmpdir=$tempRoot" @GradleArgs
exit $LASTEXITCODE
