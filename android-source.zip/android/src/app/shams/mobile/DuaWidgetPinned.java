package app.shams.mobile;
import android.content.*;
public class DuaWidgetPinned extends BroadcastReceiver {
  @Override public void onReceive(Context c,Intent i){DuaWidget.updateAll(c);}
}
