import SwiftUI
import WebKit

@main struct SHAMSApp: App {
    var body: some Scene { WindowGroup { ShamsWebView().ignoresSafeArea(.container, edges: .bottom) } }
}
struct ShamsWebView: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.userContentController.add(context.coordinator.store, name: "shamsStore")
        let web = WKWebView(frame: .zero, configuration: configuration)
        web.navigationDelegate = context.coordinator
        web.isOpaque = false
        web.backgroundColor = .black
        web.scrollView.contentInsetAdjustmentBehavior = .never
        context.coordinator.store.web = web
        if let file = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "www") { web.loadFileURL(file, allowingReadAccessTo: file.deletingLastPathComponent()) }
        return web
    }
    func updateUIView(_ view: WKWebView, context: Context) {}
    static func dismantleUIView(_ view: WKWebView, coordinator: Coordinator) { view.configuration.userContentController.removeScriptMessageHandler(forName: "shamsStore") }
    @MainActor final class Coordinator: NSObject, WKNavigationDelegate {
        let store = StoreCoordinator()
        func webView(_ view: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = action.request.url else { decisionHandler(.cancel); return }
            if url.isFileURL { decisionHandler(.allow); return }
            if action.targetFrame?.isMainFrame != false { if ["https", "mailto"].contains(url.scheme ?? "") { UIApplication.shared.open(url) }; decisionHandler(.cancel) } else { decisionHandler(.allow) }
        }
    }
}
