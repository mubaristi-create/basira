-- Email sign-up may be auto-confirmed. Existing admin UUIDs, not email claims,
-- remain the authority; a newly registered matching email must never gain admin.
begin;
do $$begin if not exists(select 1 from shams_private.admins a join public.shams_profiles p on p.id=a.user_id where lower(p.email)='mubaristi@gmail.com' and not p.disabled) then raise exception 'Existing owner admin must be present before disabling email-based promotion';end if;end$$;
create or replace function public.shams_claim_admin() returns boolean language plpgsql security definer set search_path='' as $$begin return public.shams_is_admin();end$$;
create or replace function shams_private.auth_profile() returns trigger language plpgsql security definer set search_path='' as $$begin
 insert into public.shams_profiles(id,email,display_name,last_sign_in_at) values(new.id,coalesce(new.email,''),left(coalesce(new.raw_user_meta_data->>'display_name',''),80),new.last_sign_in_at) on conflict(id) do update set email=excluded.email,last_sign_in_at=excluded.last_sign_in_at;
 if tg_op='INSERT' then insert into public.shams_events(user_id,kind) values(new.id,'registered');
 elsif new.last_sign_in_at is distinct from old.last_sign_in_at then insert into public.shams_events(user_id,kind) values(new.id,'signed_in');end if;
 return new;end$$;
revoke all on function shams_private.auth_profile() from public,anon,authenticated;
commit;
