package app.shams.mobile;
import android.Manifest;
import android.app.*;
import android.app.job.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import org.json.*;
import java.io.*;
import java.net.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class AdhanScheduler {
 private static final AtomicBoolean fetching=new AtomicBoolean(false);
 static final String PREFS="shams-native-adhan";
 static SharedPreferences prefs(Context c){return c.getSharedPreferences(PREFS,0);}
 private static JSONObject config(Context c){try{return new JSONObject(prefs(c).getString("config","{}"));}catch(Exception e){return new JSONObject();}}
 public static boolean exactAllowed(Context c){return Build.VERSION.SDK_INT<31||((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();}
 public static boolean noticesAllowed(Context c){return Build.VERSION.SDK_INT<33||c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
 public static boolean armed(Context c){return config(c).optBoolean("enabled")&&exactAllowed(c)&&noticesAllowed(c);}
 public static void configure(Context c,String input)throws Exception{
  JSONObject value=new JSONObject(input);double lat=value.getDouble("latitude"),lon=value.getDouble("longitude");
  if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)throw new IllegalArgumentException();
  ZoneId.of(value.getString("timezone"));int method=value.optInt("method",13),school=value.optInt("school",0);
  if(method<0||method>30||school<0||school>1)throw new IllegalArgumentException();
  JSONArray flags=value.getJSONArray("prayers"),names=value.getJSONArray("names");if(flags.length()!=5||names.length()!=5)throw new IllegalArgumentException();
  JSONObject clean=new JSONObject().put("enabled",value.optBoolean("enabled")).put("latitude",lat).put("longitude",lon).put("timezone",value.getString("timezone")).put("method",method).put("school",school).put("locale",value.optString("locale","az")).put("prayers",flags).put("names",names);
  JSONObject old=config(c);boolean calendarChanged=false;for(String field:new String[]{"latitude","longitude","timezone","method","school"})if(!String.valueOf(old.opt(field)).equals(String.valueOf(clean.opt(field))))calendarChanged=true;
  prefs(c).edit().putString("config",clean.toString()).apply();
  if(!old.toString().equals(clean.toString()))cancel(c);
  if(calendarChanged)prefs(c).edit().remove("events").putLong("updated",0).apply();
  if(!clean.optBoolean("enabled")){cancel(c);c.stopService(new Intent(c,AdhanPlaybackService.class));prefs(c).edit().putString("error","").apply();((JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE)).cancel(6101);return;}
  scheduleRefresh(c);rescheduleCached(c);refreshAsync(c);
 }
 static PendingIntent operation(Context c,String key,String title,long at,boolean test){Intent i=new Intent(c,AdhanReceiver.class).setAction("app.shams.mobile.ADHAN").setData(Uri.parse("shams://adhan/"+Uri.encode(key))).putExtra("key",key).putExtra("title",title).putExtra("at",at).putExtra("test",test);return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 public static void cancel(Context c){try{JSONArray old=new JSONArray(prefs(c).getString("scheduled","[]"));AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);for(int n=0;n<old.length();n++){JSONObject e=old.getJSONObject(n);am.cancel(operation(c,e.getString("key"),"",0,false));}prefs(c).edit().putString("scheduled","[]").apply();}catch(Exception ignored){}}
 public static synchronized void rescheduleCached(Context c){
  cancel(c);if(!armed(c))return;
  try{JSONArray cached=new JSONArray(prefs(c).getString("events","[]")),scheduled=new JSONArray();JSONObject cfg=config(c);JSONArray flags=cfg.getJSONArray("prayers"),titles=cfg.getJSONArray("names");long now=System.currentTimeMillis();AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
   for(int n=0;n<cached.length();n++){JSONObject e=cached.getJSONObject(n);int prayer=e.getInt("prayer");long at=e.getLong("at");String key=e.getString("key");if(!flags.optBoolean(prayer)||at<=now||prefs(c).getBoolean("fired:"+key,false))continue;String title=titles.optString(prayer,"SHAMS");am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,operation(c,key,title,at,false));scheduled.put(e);}
   prefs(c).edit().putString("scheduled",scheduled.toString()).putString("error","").apply();
  }catch(Exception e){prefs(c).edit().putString("error","schedule").apply();}
 }
 public static JSONObject status(Context c){JSONObject out=new JSONObject();try{JSONArray events=new JSONArray(prefs(c).getString("scheduled","[]"));long next=Long.MAX_VALUE;for(int n=0;n<events.length();n++)if(events.getJSONObject(n).getLong("at")>System.currentTimeMillis())next=Math.min(next,events.getJSONObject(n).getLong("at"));out.put("enabled",config(c).optBoolean("enabled")).put("exact",exactAllowed(c)).put("notifications",noticesAllowed(c)).put("count",events.length()).put("next",next==Long.MAX_VALUE?0:next).put("updated",prefs(c).getLong("updated",0)).put("error",prefs(c).getString("error","")).put("fetching",fetching.get());}catch(Exception ignored){}return out;}
 public static boolean test(Context c){if(!exactAllowed(c)||!noticesAllowed(c))return false;long at=System.currentTimeMillis()+10000;((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,operation(c,"test-"+at,"SHAMS · Azan",at,true));return true;}
 private static JSONObject readJson(String url)throws Exception{HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();connection.setConnectTimeout(15000);connection.setReadTimeout(20000);connection.setRequestProperty("User-Agent","SHAMS/1.8 (+https://mubaristi-create.github.io/basira/)");try{if(connection.getResponseCode()!=200)throw new IOException("Prayer service unavailable");try(InputStream in=connection.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream()){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){bytes.write(buffer,0,n);if(bytes.size()>1500000)throw new IOException("Response too large");}return new JSONObject(bytes.toString("UTF-8"));}}finally{connection.disconnect();}}
 static void refresh(Context c)throws Exception{
  JSONObject cfg=config(c);if(!cfg.optBoolean("enabled"))return;if(System.currentTimeMillis()-prefs(c).getLong("updated",0)<6*60*60*1000L)return;String signature=cfg.toString(),timezone=cfg.getString("timezone");LocalDate today=LocalDate.now(ZoneId.of(timezone)),last=today.plusDays(14);Set<YearMonth> months=new LinkedHashSet<>();months.add(YearMonth.from(today));months.add(YearMonth.from(last));JSONArray events=new JSONArray();String[] keys={"Fajr","Dhuhr","Asr","Maghrib","Isha"};
  for(YearMonth month:months){String query="latitude="+cfg.getDouble("latitude")+"&longitude="+cfg.getDouble("longitude")+"&method="+cfg.getInt("method")+"&school="+cfg.getInt("school")+"&timezonestring="+URLEncoder.encode(timezone,"UTF-8");JSONObject response=readJson("https://api.aladhan.com/v1/calendar/"+month.getYear()+"/"+month.getMonthValue()+"?"+query);if(response.optInt("code")!=200)throw new IOException("Invalid prayer calendar");JSONArray days=response.getJSONArray("data");
   for(int d=0;d<days.length();d++){JSONObject item=days.getJSONObject(d);String date=item.getJSONObject("date").getJSONObject("gregorian").getString("date");LocalDate local=LocalDate.parse(date,java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy"));if(local.isBefore(today)||local.isAfter(last))continue;for(int i=0;i<5;i++){long at=AdhanTime.epoch(date,item.getJSONObject("timings").getString(keys[i]),timezone);events.put(new JSONObject().put("at",at).put("prayer",i).put("key",local.toString()+"-"+i));}}
  }
  if(!signature.equals(config(c).toString()))return;if(events.length()<5)throw new IOException("Calendar empty");prefs(c).edit().putString("events",events.toString()).putLong("updated",System.currentTimeMillis()).putString("error","").apply();rescheduleCached(c);
 }
 public static void refreshAsync(Context c){final Context app=c.getApplicationContext();if(!fetching.compareAndSet(false,true))return;final String signature=config(app).toString();new Thread(()->{try{refresh(app);}catch(Exception e){prefs(app).edit().putString("error","network").apply();}finally{fetching.set(false);if(!signature.equals(config(app).toString())&&config(app).optBoolean("enabled"))refreshAsync(app);}},"shams-adhan-refresh").start();}
 public static void scheduleRefresh(Context c){if(!config(c).optBoolean("enabled"))return;JobInfo job=new JobInfo.Builder(6101,new ComponentName(c,AdhanRefreshJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(12*60*60*1000L).build();((JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE)).schedule(job);}
 static void invalidConfiguration(Context c){cancel(c);c.stopService(new Intent(c,AdhanPlaybackService.class));prefs(c).edit().putString("config","{\"enabled\":false}").putString("error","configuration").apply();((JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE)).cancel(6101);}
}
