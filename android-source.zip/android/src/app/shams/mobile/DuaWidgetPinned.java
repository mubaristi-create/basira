package app.shams.mobile;
import android.content.*;
public class DuaWidgetPinned extends BroadcastReceiver {
  @Override public void onReceive(Context c,Intent i){int id=i.getIntExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID,-1);String token=i.getStringExtra("token");if(id<0||token==null)return;android.content.SharedPreferences p=c.getSharedPreferences("screen-dua",0);String title=p.getString(token+":title",null),body=p.getString(token+":body",null);if(title==null||body==null)return;DuaWidget.save(c,id,title,body);p.edit().remove(token+":title").remove(token+":body").apply();DuaWidget.updateAll(c);}
}
