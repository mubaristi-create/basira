package app.shams.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.*;
import android.view.WindowInsets;
import java.io.*;
import java.net.URLConnection;
import java.util.*;

public class MainActivity extends Activity {
  private static final String ASSET_HOST="appassets.androidplatform.net";
  private static final String PUBLIC_URL="https://mubaristi-create.github.io/basira/";
  private WebView web;
  private GeolocationPermissions.Callback geoCallback;
  private String geoOrigin;
  private ValueCallback<Uri[]> fileCallback;

  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    web=new WebView(this); setContentView(web);
    web.setOnApplyWindowInsetsListener((v,insets)->{
      if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));}
      return insets;
    });
    WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(false);settings.setAllowContentAccess(true);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    settings.setMediaPlaybackRequiresUserGesture(true);settings.setGeolocationEnabled(true);
    WebView.setWebContentsDebuggingEnabled(false);
    web.addJavascriptInterface(new ShareBridge(),"ShamsAndroid");
    web.setWebViewClient(new WebViewClient(){
      @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return assetResponse(request);}
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
        Uri uri=request.getUrl();if(trusted(uri))return false;if(!request.isForMainFrame())return true;
        String scheme=uri.getScheme();if("https".equals(scheme)||"http".equals(scheme)||"mailto".equals(scheme)){try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}}
        return true;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){
        if(!origin.startsWith("https://"+ASSET_HOST)){callback.invoke(origin,false,false);return;}
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){callback.invoke(origin,true,false);return;}
        geoOrigin=origin;geoCallback=callback;requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},7);
      }
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> result,FileChooserParams params){
        if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=result;
        try{Intent intent=params.createIntent();intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(intent,8);return true;}catch(Exception e){fileCallback.onReceiveValue(null);fileCallback=null;return false;}
      }
    });
    if(state==null||web.restoreState(state)==null)web.loadUrl("https://"+ASSET_HOST+"/assets/index.html");
  }
  private boolean trusted(Uri uri){return "https".equals(uri.getScheme())&&ASSET_HOST.equals(uri.getHost())&&uri.getPath()!=null&&uri.getPath().startsWith("/assets/");}
  private WebResourceResponse assetResponse(WebResourceRequest request){
    Uri uri=request.getUrl();if(!ASSET_HOST.equals(uri.getHost()))return null;
    try{
      if(!trusted(uri))return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
      String name=uri.getPath().substring(8);if(name.contains("..")||name.contains("\\")||name.indexOf(0)>=0)throw new IOException();
      byte[] bytes;try(InputStream input=getAssets().open(name);ByteArrayOutputStream output=new ByteArrayOutputStream()){byte[] buffer=new byte[16384];int n;while((n=input.read(buffer))!=-1)output.write(buffer,0,n);bytes=output.toByteArray();}
      String mime=URLConnection.guessContentTypeFromName(name);if(name.endsWith(".js"))mime="application/javascript";if(name.endsWith(".css"))mime="text/css";if(name.endsWith(".svg"))mime="image/svg+xml";if(name.endsWith(".mp3"))mime="audio/mpeg";if(name.endsWith(".ogg"))mime="audio/ogg";if(mime==null)mime="application/octet-stream";
      Map<String,String> headers=new HashMap<>();headers.put("Accept-Ranges","bytes");headers.put("Cache-Control","no-cache");headers.put("X-Content-Type-Options","nosniff");
      String range=request.getRequestHeaders().get("Range");if(range==null)range=request.getRequestHeaders().get("range");int start=0,end=bytes.length-1,status=200;
      if(range!=null&&range.matches("bytes=\\d+-\\d*")){String[] parts=range.substring(6).split("-",-1);start=Integer.parseInt(parts[0]);if(parts.length>1&&!parts[1].isEmpty())end=Math.min(end,Integer.parseInt(parts[1]));if(start<0||start>end||end>=bytes.length)throw new IOException();status=206;headers.put("Content-Range","bytes "+start+"-"+end+"/"+bytes.length);}
      headers.put("Content-Length",String.valueOf(end-start+1));return new WebResourceResponse(mime,mime.startsWith("text/")||mime.contains("javascript")?"UTF-8":null,status,status==206?"Partial Content":"OK",headers,new ByteArrayInputStream(bytes,start,end-start+1));
    }catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
  }
  public class ShareBridge {
    @JavascriptInterface public void shareApp(String text,String url){if(!PUBLIC_URL.equals(url))return;final String message=(text==null?"SHAMS":text.substring(0,Math.min(text.length(),500)))+"\n"+PUBLIC_URL;runOnUiThread(()->{Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");share.putExtra(Intent.EXTRA_TEXT,message);startActivity(Intent.createChooser(share,"SHAMS"));});}
  }
  @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){super.onRequestPermissionsResult(code,permissions,results);if(code==7&&geoCallback!=null){boolean allowed=false;for(int result:results)if(result==PackageManager.PERMISSION_GRANTED)allowed=true;geoCallback.invoke(geoOrigin,allowed,false);geoCallback=null;}}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==8&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}}
  @Override protected void onSaveInstanceState(Bundle state){web.saveState(state);super.onSaveInstanceState(state);}
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onPause(){super.onPause();web.evaluateJavascript("document.querySelectorAll('audio').forEach(function(a){a.pause()})",null);web.onPause();}
  @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
  @Override protected void onDestroy(){if(web!=null){web.removeJavascriptInterface("ShamsAndroid");web.destroy();}super.onDestroy();}
}
