package app.shams.mobile;
import android.content.*;
public class AdhanReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){String key=i.getStringExtra("key");long due=i.getLongExtra("at",0);boolean test=i.getBooleanExtra("test",false);if(key==null||Math.abs(System.currentTimeMillis()-due)>10*60*1000L||(!test&&!AdhanScheduler.armed(c)))return;if(AdhanScheduler.prefs(c).getBoolean("fired:"+key,false))return;AdhanScheduler.prefs(c).edit().putBoolean("fired:"+key,true).apply();try{c.startForegroundService(new Intent(c,AdhanPlaybackService.class).putExtra("title",i.getStringExtra("title")));}catch(Exception e){AdhanScheduler.prefs(c).edit().putString("error","playback").apply();}}
}
