package app.shams.mobile;
import java.util.concurrent.ThreadLocalRandom;
final class AdhanMessages {
 static String choose(String locale,String previous){
  String[] lines;
  switch(locale){
   case "tr":lines=new String[]{"Bir mola ver, namaz vakti geldi.","Günün telaşına kısa bir ara: namaza davetlisin.","Kalbini dinlendir, namazını hatırla.","Ezan okunuyor. Haydi namaza.","İşlerine ara ver, Rabbine yönel."};break;
   case "ru":lines=new String[]{"Сделайте паузу: наступило время намаза.","Отложите дела на минуту и обратитесь к молитве.","Звучит азан. Пришло время намаза.","Пусть молитва станет спокойной паузой в вашем дне.","Время вспомнить об Аллахе и совершить намаз."};break;
   case "en":lines=new String[]{"Take a peaceful pause. It is time for prayer.","The adhan is calling. Come to prayer.","Set your tasks aside for a moment of prayer.","A moment to remember Allah: prayer time is here.","Let prayer be a calm pause in your day."};break;
   case "ar":lines=new String[]{"حان وقت الصلاة، خذ استراحة هادئة.","يرتفع الأذان، حي على الصلاة.","اترك مشاغلك قليلًا وأقبل على الصلاة.","لحظة لذكر الله، حان وقت الصلاة.","اجعل الصلاة سكينة في يومك."};break;
   default:lines=new String[]{"İşlərinə bir az fasilə ver, namaz vaxtıdır.","Azan səslənir. Namaza gəl.","Qəlbinə sakit bir fasilə ver: namaz vaxtı gəldi.","Günün qayğıları arasında Rəbbini xatırla.","İşlərini bir anlıq kənara qoy, namaza yönəl."};
  }
  int offset=ThreadLocalRandom.current().nextInt(lines.length);for(int n=0;n<lines.length;n++){String line=lines[(offset+n)%lines.length];if(!line.equals(previous))return line;}return lines[0];
 }
}
