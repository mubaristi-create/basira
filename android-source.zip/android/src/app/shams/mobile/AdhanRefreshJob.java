package app.shams.mobile;
import android.app.job.*;
public class AdhanRefreshJob extends JobService {
 @Override public boolean onStartJob(JobParameters p){new Thread(()->{try{AdhanScheduler.refresh(getApplicationContext());jobFinished(p,false);}catch(Exception e){jobFinished(p,true);}},"shams-adhan-job").start();return true;}
 @Override public boolean onStopJob(JobParameters p){return true;}
}
