package app.shams.mobile;
import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import java.io.*;
public class AdhanPlaybackService extends Service {
 private Notification finalNotice;private MediaPlayer player;private AudioManager audio;private AudioFocusRequest focus;
 @Override public IBinder onBind(Intent i){return null;}
 @Override public int onStartCommand(Intent i,int flags,int id){if(i!=null&&"STOP".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}String title=i==null?"SHAMS · Azan":i.getStringExtra("title");NotificationManager notifications=getSystemService(NotificationManager.class);NotificationChannel channel=new NotificationChannel("shams_adhan_v1","SHAMS · Azan",NotificationManager.IMPORTANCE_DEFAULT);channel.setSound(null,null);notifications.createNotificationChannel(channel);
  PendingIntent stop=PendingIntent.getService(this,0,new Intent(this,AdhanPlaybackService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
  String locale="az";try{locale=new org.json.JSONObject(AdhanScheduler.prefs(this).getString("config","{}")).optString("locale","az");}catch(Exception ignored){} String message=AdhanMessages.choose(locale,AdhanScheduler.prefs(this).getString("last-call",""));AdhanScheduler.prefs(this).edit().putString("last-call",message).apply();
  finalNotice=new Notification.Builder(this,"shams_adhan_v1").setSmallIcon(R.drawable.ic_adhan).setContentTitle(title==null?"SHAMS":title).setContentText(message).setStyle(new Notification.BigTextStyle().bigText(message)).setContentIntent(open).setAutoCancel(true).build();
  Notification notice=new Notification.Builder(this,"shams_adhan_v1").setSmallIcon(R.drawable.ic_adhan).setContentTitle(title==null?"SHAMS":title).setContentText(message).setStyle(new Notification.BigTextStyle().bigText(message)).setContentIntent(open).setOngoing(true).addAction(new Notification.Action.Builder(null,"Dayandır / Stop",stop).build()).build();
  if(Build.VERSION.SDK_INT>=29)startForeground(6102,notice,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);else startForeground(6102,notice);
  try{if(player!=null){player.release();player=null;}File file=new File(getFilesDir(),"adhan-user.webm");if(!file.exists()){try(InputStream input=getAssets().open("audio/adhan-user.webm");FileOutputStream output=new FileOutputStream(file)){byte[] b=new byte[16384];int n;while((n=input.read(b))!=-1)output.write(b,0,n);}}
   AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();audio=(AudioManager)getSystemService(AUDIO_SERVICE);focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(attributes).setOnAudioFocusChangeListener(change->{if(change==AudioManager.AUDIOFOCUS_LOSS)stopSelf();}).build();if(audio.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED)throw new IOException("Audio focus unavailable");
   player=new MediaPlayer();player.setAudioAttributes(attributes);player.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);player.setDataSource(file.getAbsolutePath());player.setOnCompletionListener(p->stopSelf());player.setOnErrorListener((p,what,extra)->{AdhanScheduler.prefs(this).edit().putString("error","playback").apply();stopSelf();return true;});player.prepare();player.start();AdhanScheduler.prefs(this).edit().putString("error","").apply();
  }catch(Exception e){AdhanScheduler.prefs(this).edit().putString("error","playback").apply();stopSelf();}return START_NOT_STICKY;
 }
 @Override public void onDestroy(){if(player!=null){player.release();player=null;}if(audio!=null&&focus!=null)audio.abandonAudioFocusRequest(focus);stopForeground(STOP_FOREGROUND_DETACH);if(finalNotice!=null)getSystemService(NotificationManager.class).notify(6102,finalNotice);super.onDestroy();}
}
