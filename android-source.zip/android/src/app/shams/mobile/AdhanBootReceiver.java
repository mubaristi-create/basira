package app.shams.mobile;
import android.content.*;
public class AdhanBootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){AdhanScheduler.rescheduleCached(c);AdhanScheduler.scheduleRefresh(c);AdhanScheduler.refreshAsync(c);}
}
