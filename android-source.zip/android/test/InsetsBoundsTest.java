import app.shams.mobile.InsetsBounds;
import java.util.Arrays;
public class InsetsBoundsTest {
 static void check(int[] expected,int[] actual){if(!Arrays.equals(expected,actual))throw new AssertionError(Arrays.toString(actual));}
 public static void main(String[] args){
  check(new int[]{0,24,0,48},InsetsBounds.resolve(new int[]{0,24,0,48},new int[4],new int[4]));
  check(new int[]{0,42,0,24},InsetsBounds.resolve(new int[]{0,24,0,24},new int[]{0,42,0,0},new int[4]));
  check(new int[]{44,0,48,0},InsetsBounds.resolve(new int[]{0,0,48,0},new int[]{44,0,0,0},new int[4]));
  check(new int[]{0,42,0,320},InsetsBounds.resolve(new int[]{0,24,0,48},new int[]{0,42,0,0},new int[]{0,0,0,320}));
  check(new int[]{0,24,0,24},InsetsBounds.resolve(new int[]{0,24,0,24},new int[4],new int[4]));
  check(new int[4],InsetsBounds.resolve(new int[]{-1,-1,-1,-1},new int[4],new int[4]));
  System.out.println("PASS: gesture/3-button, cutout, landscape, keyboard open/close, no additive insets.");
 }
}
