begin;
create or replace function public.shams_admin_records(p_kind text,p_search text default '',p_offset integer default 0) returns jsonb language plpgsql security definer set search_path='' as $$declare rows jsonb; total bigint; q text:='%'||left(coalesce(p_search,''),100)||'%';off integer:=greatest(0,p_offset);begin
 if not public.shams_is_admin() then raise exception 'Admin required';end if;
 if p_kind='profiles' then
 select count(*) into total from public.shams_profiles where email ilike q or display_name ilike q;
 select coalesce(jsonb_agg(x),'[]') into rows from(select p.*,exists(select 1 from shams_private.admins a where a.user_id=p.id) is_admin from public.shams_profiles p where p.email ilike q or p.display_name ilike q order by p.created_at desc,p.id limit 50 offset off)x;
 elsif p_kind='events' then
 select count(*) into total from public.shams_events e left join public.shams_profiles p on p.id=e.user_id where e.kind ilike q or p.email ilike q;
 select coalesce(jsonb_agg(x),'[]') into rows from(select e.*,p.email from public.shams_events e left join public.shams_profiles p on p.id=e.user_id where e.kind ilike q or p.email ilike q order by e.created_at desc,e.id desc limit 50 offset off)x;
 elsif p_kind='audit' then
 select count(*) into total from public.shams_admin_audit where action ilike q or target ilike q;
 select coalesce(jsonb_agg(x),'[]') into rows from(select * from public.shams_admin_audit where action ilike q or target ilike q order by created_at desc,id desc limit 50 offset off)x;
 else raise exception 'Unknown record type';end if;
 return jsonb_build_object('rows',rows,'total',total,'offset',off);end$$;
revoke all on function public.shams_admin_records(text,text,integer) from public,anon;
grant execute on function public.shams_admin_records(text,text,integer) to authenticated;
commit;
