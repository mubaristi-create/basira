package app.shams.mobile;
public class AdhanMessagesTest {
 public static void main(String[] args){for(String locale:new String[]{"az","tr","ru","en","ar","unknown"}){String previous="";for(int i=0;i<100;i++){String text=AdhanMessages.choose(locale,previous);if(text.isEmpty()||text.equals(previous))throw new AssertionError("Empty or repeated call: "+locale);previous=text;}}System.out.println("PASS: five notification locales, safe fallback, no consecutive repeated call");}
}
