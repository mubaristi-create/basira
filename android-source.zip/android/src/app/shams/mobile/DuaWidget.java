package app.shams.mobile;
import android.app.PendingIntent;
import android.appwidget.*;
import android.content.*;
import android.widget.RemoteViews;
public class DuaWidget extends AppWidgetProvider {
  static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);new DuaWidget().onUpdate(c,m,m.getAppWidgetIds(new ComponentName(c,DuaWidget.class)));}
  @Override public void onUpdate(Context c,AppWidgetManager manager,int[] ids){
    android.content.SharedPreferences prefs=c.getSharedPreferences("screen-dua",0);
    for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.dua_widget);
      v.setTextViewText(R.id.dua_title,prefs.getString("title","SHAMS"));
      v.setTextViewText(R.id.dua_text,prefs.getString("body","رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ\n\nQuran 2:201"));
      Intent open=new Intent(c,MainActivity.class).putExtra("screenDua",true);
      v.setOnClickPendingIntent(R.id.dua_root,PendingIntent.getActivity(c,14,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
      manager.updateAppWidget(id,v);
    }
  }
}
