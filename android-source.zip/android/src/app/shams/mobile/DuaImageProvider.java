package app.shams.mobile;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.*;
public class DuaImageProvider extends ContentProvider {
  @Override public boolean onCreate(){return true;}
  private File fileFor(Uri u){String p=u.getPath();if("/dua.png".equals(p))return new File(getContext().getCacheDir(),"screen-dua.png");if(p!=null&&p.matches("/share/[a-f0-9-]{36}\\.png"))return new File(getContext().getCacheDir(),"share-"+p.substring(7));throw new IllegalArgumentException("Invalid image");}
  private void check(Uri u){fileFor(u);}
  @Override public String getType(Uri u){check(u);return "image/png";}
  @Override public ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException{if(!"r".equals(mode))throw new FileNotFoundException();return ParcelFileDescriptor.open(fileFor(u),ParcelFileDescriptor.MODE_READ_ONLY);}
  @Override public Cursor query(Uri u,String[] p,String s,String[] a,String order){File file=fileFor(u);String[] columns=p==null?new String[]{android.provider.OpenableColumns.DISPLAY_NAME,android.provider.OpenableColumns.SIZE}:p;android.database.MatrixCursor cursor=new android.database.MatrixCursor(columns,1);Object[] row=new Object[columns.length];for(int i=0;i<columns.length;i++){if(android.provider.OpenableColumns.DISPLAY_NAME.equals(columns[i]))row[i]="SHAMS-dua.png";if(android.provider.OpenableColumns.SIZE.equals(columns[i]))row[i]=file.length();}cursor.addRow(row);return cursor;}
  @Override public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
  @Override public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
  @Override public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
