package app.shams.mobile;

/** Union, not sum: a keyboard and navigation bar occupy overlapping screen edges. */
public final class InsetsBounds {
  private InsetsBounds() {}
  public static int[] resolve(int[] bars, int[] cutout, int[] ime) {
    int[] safe=new int[4];
    for(int edge=0;edge<4;edge++)safe[edge]=Math.max(0,Math.max(bars[edge],Math.max(cutout[edge],ime[edge])));
    return safe;
  }
}
