import app.shams.mobile.AdhanTime;
import java.time.Instant;
public class AdhanTimeTest {
 static void same(long actual,String expected){if(actual!=Instant.parse(expected).toEpochMilli())throw new AssertionError(expected);}
 public static void main(String[] args){
  same(AdhanTime.epoch("03-11-2026","05:40 (+04)","Asia/Baku"),"2026-11-03T01:40:00Z");
  same(AdhanTime.epoch("07-03-2026","06:00","America/New_York"),"2026-03-07T11:00:00Z");
  same(AdhanTime.epoch("09-03-2026","06:00","America/New_York"),"2026-03-09T10:00:00Z");
  same(AdhanTime.epoch("31-12-2026","23:59","Asia/Tokyo"),"2026-12-31T14:59:00Z");
  for(String time:new String[]{"--:--","25:99","sunset",null}){boolean failed=false;try{AdhanTime.epoch("03-11-2026",time,"Asia/Baku");}catch(Exception expected){failed=true;}if(!failed)throw new AssertionError("Invalid time accepted");}
  System.out.println("PASS: native prayer epochs, Baku, timezone/DST, year boundary, invalid time guards.");
 }
}
