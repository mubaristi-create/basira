begin;
alter table public.shams_content add column if not exists public_id integer generated always as identity unique;
commit;
