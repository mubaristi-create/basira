#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p SHAMS/www
find ../dist -maxdepth 1 -type f \( -name '*.html' -o -name '*.js' -o -name '*.css' -o -name '*.webmanifest' \) -exec cp {} SHAMS/www/ \;
cp -R ../dist/icons ../dist/audio SHAMS/www/
echo 'Web assets prepared. Open SHAMS.xcodeproj and set your real bundle ID / team in StoreConfig.xcconfig.'
