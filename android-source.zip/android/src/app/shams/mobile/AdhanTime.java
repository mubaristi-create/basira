package app.shams.mobile;
import java.time.*;
import java.time.format.DateTimeFormatter;
public final class AdhanTime {
 private AdhanTime(){}
 public static long epoch(String date,String time,String timezone){
  if(time==null||!time.matches("\\d{2}:\\d{2}.*"))throw new IllegalArgumentException("Prayer time unavailable");
  return LocalDate.parse(date,DateTimeFormatter.ofPattern("dd-MM-yyyy")).atTime(LocalTime.parse(time.substring(0,5))).atZone(ZoneId.of(timezone)).toInstant().toEpochMilli();
 }
}
