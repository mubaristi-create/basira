package app.shams.mobile;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Tokens encrypted with a non-exportable, per-install Android Keystore key. */
final class SessionVault {
 private final Context context;
 SessionVault(Context c){context=c.getApplicationContext();}
 private SecretKey key() throws Exception {
  KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
  if(store.containsAlias("shams-session-v1"))return (SecretKey)store.getKey("shams-session-v1",null);
  KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
  generator.init(new KeyGenParameterSpec.Builder("shams-session-v1",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return generator.generateKey();
 }
 private boolean allowed(String name){return "session".equals(name)||"oauth".equals(name);}
 synchronized boolean write(String name,String value){
  if(!allowed(name)||value==null||value.length()>64000)return false;
  if(value.isEmpty())return context.getSharedPreferences("session-vault",0).edit().remove(name).commit();
  try{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());byte[] data=cipher.doFinal(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));return context.getSharedPreferences("session-vault",0).edit().putString(name,Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(data,Base64.NO_WRAP)).commit();}catch(Exception e){return false;}
 }
 synchronized String read(String name){
  if(!allowed(name))return "";String value=context.getSharedPreferences("session-vault",0).getString(name,"");if(value.isEmpty())return "";
  try{String[] parts=value.split(":",2);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));return new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){return "";}
 }
}
