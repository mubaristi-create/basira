import Foundation
import StoreKit
import WebKit

@MainActor final class StoreCoordinator: NSObject, WKScriptMessageHandler {
    static let productID = "shams_premium_yearly"
    weak var web: WKWebView?
    private var transactions: [UInt64: Transaction] = [:]
    private var updates: Task<Void, Never>?
    override init() {
        super.init()
        updates = Task { [weak self] in
            for await update in Transaction.updates {
                guard let self else { return }
                await self.deliver(update)
            }
        }
    }
    deinit { updates?.cancel() }
    func send(_ data: [String: Any]) {
        guard let bytes = try? JSONSerialization.data(withJSONObject: data), let json = String(data: bytes, encoding: .utf8) else { return }
        web?.evaluateJavaScript("window.shamsStoreEvent && window.shamsStoreEvent(\(json))")
    }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, message.name == "shamsStore", let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        guard let url = message.frameInfo.request.url, url.isFileURL else { return }
        Task {
            do {
                switch action {
                case "products":
                    guard let product = try await Product.products(for: [Self.productID]).first, product.type == .autoRenewable, product.subscription?.subscriptionPeriod.unit == .year, product.subscription?.subscriptionPeriod.value == 1 else { send(["type": "unavailable"]); return }
                    send(["type": "product", "id": Self.productID, "value": NSDecimalNumber(decimal: product.price).stringValue, "currency": product.priceFormatStyle.currencyCode, "formatted": product.displayPrice])
                    for await result in Transaction.currentEntitlements {
                        if case .verified(let transaction) = result, transaction.productID == Self.productID { await deliver(result) }
                    }
                case "purchase":
                    guard let raw = body["userId"] as? String, let user = UUID(uuidString: raw), let product = try await Product.products(for: [Self.productID]).first else { send(["type": "error"]); return }
                    switch try await product.purchase(options: [.appAccountToken(user)]) {
                    case .success(let result): await deliver(result)
                    case .pending: send(["type": "pending"])
                    case .userCancelled: send(["type": "canceled"])
                    @unknown default: send(["type": "error"])
                    }
                case "restore":
                    try await AppStore.sync()
                    var found = false
                    for await result in Transaction.currentEntitlements {
                        if case .verified(let transaction) = result, transaction.productID == Self.productID { found = true; await deliver(result) }
                    }
                    if !found { send(["type": "none"]) }
                case "finish":
                    if let raw = body["transactionId"] as? String, let id = UInt64(raw), let transaction = transactions[id] { await transaction.finish(); transactions.removeValue(forKey: id) }
                default: break
                }
            } catch { send(["type": "error"]) }
        }
    }
    private func deliver(_ result: VerificationResult<Transaction>) async {
        guard case .verified(let transaction) = result, transaction.productID == Self.productID else { send(["type": "error"]); return }
        transactions[transaction.id] = transaction
        // The server verifies the JWS and queries Apple's current subscription status.
        // Finish only after the JavaScript client receives a successful server response.
        send(["type": "purchase", "store": "apple", "jws": result.jwsRepresentation, "transactionId": String(transaction.id)])
    }
}
