package app.shams.mobile;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.*;
public class DuaImageProvider extends ContentProvider {
  @Override public boolean onCreate(){return true;}
  private void check(Uri u){if(!"/dua.png".equals(u.getPath()))throw new IllegalArgumentException("Invalid image");}
  @Override public String getType(Uri u){check(u);return "image/png";}
  @Override public ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException{check(u);if(!"r".equals(mode))throw new FileNotFoundException();return ParcelFileDescriptor.open(new File(getContext().getCacheDir(),"screen-dua.png"),ParcelFileDescriptor.MODE_READ_ONLY);}
  @Override public Cursor query(Uri u,String[] p,String s,String[] a,String order){check(u);return null;}
  @Override public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
  @Override public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
  @Override public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
