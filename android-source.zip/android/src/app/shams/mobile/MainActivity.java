package app.shams.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.*;
import android.view.WindowInsets;
import java.io.*;
import java.net.URLConnection;
import java.util.*;

public class MainActivity extends Activity implements android.hardware.SensorEventListener {
  private static final String ASSET_HOST="appassets.androidplatform.net";
  private static final String PUBLIC_URL="https://mubaristi-create.github.io/basira/";
  private WebView web;
  private GeolocationPermissions.Callback geoCallback;
  private String geoOrigin;
  private ValueCallback<Uri[]> fileCallback;
  private android.hardware.SensorManager sensors;
  private boolean compassWanted=false;
  private android.hardware.GeomagneticField magneticField;
  private float[] gravity,magnetism;
  private long lastHeading=0;
  private int compassAccuracy=3;
  private byte[] pendingDuaImage;
  private int configureWidget=-1;
  private StoreBilling storeBilling;

  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    if(android.appwidget.AppWidgetManager.ACTION_APPWIDGET_CONFIGURE.equals(getIntent().getAction())){configureWidget=getIntent().getIntExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID,-1);setResult(RESULT_CANCELED);}
    web=new WebView(this); setContentView(web);
    web.setOnApplyWindowInsetsListener((v,insets)->{
      if(Build.VERSION.SDK_INT>=30){android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());android.graphics.Insets ime=insets.getInsets(WindowInsets.Type.ime());v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));}
      return insets;
    });
    WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(false);settings.setAllowContentAccess(true);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    settings.setMediaPlaybackRequiresUserGesture(true);settings.setGeolocationEnabled(true);
    settings.setUserAgentString(settings.getUserAgentString()+" SHAMS/1.6 (+https://mubaristi-create.github.io/basira/)");
    WebView.setWebContentsDebuggingEnabled(false);
    web.addJavascriptInterface(new ShareBridge(),"ShamsAndroid");
    storeBilling=new StoreBilling(this,json->runOnUiThread(()->{if(web!=null&&trusted(Uri.parse(web.getUrl()==null?"":web.getUrl())))web.evaluateJavascript("window.shamsStoreEvent&&window.shamsStoreEvent("+json+")",null);}));
    web.setWebViewClient(new WebViewClient(){
      @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return assetResponse(request);}
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
        Uri uri=request.getUrl();if(trusted(uri))return false;if(!request.isForMainFrame())return true;
        String scheme=uri.getScheme();if("https".equals(scheme)||"http".equals(scheme)||"mailto".equals(scheme)){try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception ignored){}}
        return true;
      }
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public void onGeolocationPermissionsShowPrompt(String origin,GeolocationPermissions.Callback callback){
        if(!origin.startsWith("https://"+ASSET_HOST)){callback.invoke(origin,false,false);return;}
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED){callback.invoke(origin,true,false);return;}
        geoOrigin=origin;geoCallback=callback;requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},7);
      }
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> result,FileChooserParams params){
        if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=result;
        try{Intent intent=params.createIntent();intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(intent,8);return true;}catch(Exception e){fileCallback.onReceiveValue(null);fileCallback=null;return false;}
      }
    });
    if(state==null||web.restoreState(state)==null)web.loadUrl("https://"+ASSET_HOST+"/assets/index.html"+(configureWidget>=0||getIntent().getBooleanExtra("screenDua",false)?"#widgets":""));
  }
  private boolean trusted(Uri uri){return "https".equals(uri.getScheme())&&ASSET_HOST.equals(uri.getHost())&&uri.getPath()!=null&&uri.getPath().startsWith("/assets/");}
  private WebResourceResponse assetResponse(WebResourceRequest request){
    Uri uri=request.getUrl();if(!ASSET_HOST.equals(uri.getHost()))return null;
    try{
      if(!trusted(uri))return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));
      String name=uri.getPath().substring(8);if(name.contains("..")||name.contains("\\")||name.indexOf(0)>=0)throw new IOException();
      byte[] bytes;try(InputStream input=getAssets().open(name);ByteArrayOutputStream output=new ByteArrayOutputStream()){byte[] buffer=new byte[16384];int n;while((n=input.read(buffer))!=-1)output.write(buffer,0,n);bytes=output.toByteArray();}
      String mime=URLConnection.guessContentTypeFromName(name);if(name.endsWith(".js"))mime="application/javascript";if(name.endsWith(".css"))mime="text/css";if(name.endsWith(".svg"))mime="image/svg+xml";if(name.endsWith(".mp3"))mime="audio/mpeg";if(name.endsWith(".ogg"))mime="audio/ogg";if(name.endsWith(".webm"))mime="audio/webm";if(mime==null)mime="application/octet-stream";
      Map<String,String> headers=new HashMap<>();headers.put("Accept-Ranges","bytes");headers.put("Cache-Control","no-cache");headers.put("X-Content-Type-Options","nosniff");
      String range=request.getRequestHeaders().get("Range");if(range==null)range=request.getRequestHeaders().get("range");int start=0,end=bytes.length-1,status=200;
      if(range!=null&&range.matches("bytes=\\d+-\\d*")){String[] parts=range.substring(6).split("-",-1);start=Integer.parseInt(parts[0]);if(parts.length>1&&!parts[1].isEmpty())end=Math.min(end,Integer.parseInt(parts[1]));if(start<0||start>end||end>=bytes.length)throw new IOException();status=206;headers.put("Content-Range","bytes "+start+"-"+end+"/"+bytes.length);}
      headers.put("Content-Length",String.valueOf(end-start+1));return new WebResourceResponse(mime,mime.startsWith("text/")||mime.contains("javascript")?"UTF-8":null,status,status==206?"Partial Content":"OK",headers,new ByteArrayInputStream(bytes,start,end-start+1));
    }catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",Collections.emptyMap(),new ByteArrayInputStream(new byte[0]));}
  }
  public class ShareBridge {
    @JavascriptInterface public void storeProducts(String plan){runOnUiThread(()->storeBilling.details(plan));}
    @JavascriptInterface public void storePurchase(String user){runOnUiThread(()->storeBilling.buy(user));}
    @JavascriptInterface public void storeRestore(){runOnUiThread(()->storeBilling.restore());}
    @JavascriptInterface public void configureAdhan(String json){try{AdhanScheduler.configure(MainActivity.this,json);}catch(Exception ignored){}}
    @JavascriptInterface public String adhanStatus(){return AdhanScheduler.status(MainActivity.this).toString();}
    @JavascriptInterface public boolean testAdhan(){return AdhanScheduler.test(MainActivity.this);}
    @JavascriptInterface public void requestAdhanPermissions(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=33&&!AdhanScheduler.noticesAllowed(MainActivity.this)){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},16);return;}openExactPermission();});}
    @JavascriptInterface public void shareDuaText(String title,String body){if(title==null||body==null||title.length()>200||body.length()>32000)return;runOnUiThread(()->{Intent share=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT,title).putExtra(Intent.EXTRA_TEXT,body);startActivity(Intent.createChooser(share,"SHAMS"));});}
    @JavascriptInterface public void shareDuaImage(String data,String title){
      if(data==null||title==null||title.length()>200||!data.startsWith("data:image/png;base64,")||data.length()>12000000)return;
      try{byte[] image=android.util.Base64.decode(data.substring(22),android.util.Base64.DEFAULT);android.graphics.BitmapFactory.Options o=new android.graphics.BitmapFactory.Options();o.inJustDecodeBounds=true;android.graphics.BitmapFactory.decodeByteArray(image,0,image.length,o);if(o.outWidth!=1080||o.outHeight!=1920)return;
        File[] old=getCacheDir().listFiles((dir,name)->name.startsWith("share-")&&name.endsWith(".png"));if(old!=null)for(File f:old)if(f.lastModified()<System.currentTimeMillis()-86400000L)f.delete();
        String id=UUID.randomUUID().toString();File file=new File(getCacheDir(),"share-"+id+".png");try(FileOutputStream output=new FileOutputStream(file)){output.write(image);}
        Uri uri=Uri.parse("content://app.shams.mobile.dua/share/"+id+".png");runOnUiThread(()->{Intent share=new Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM,uri).putExtra(Intent.EXTRA_TEXT,title+"\nSHAMS").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);share.setClipData(android.content.ClipData.newRawUri("SHAMS",uri));startActivity(Intent.createChooser(share,"SHAMS"));});
      }catch(Exception ignored){runOnUiThread(()->android.widget.Toast.makeText(MainActivity.this,"Unable to prepare image",android.widget.Toast.LENGTH_LONG).show());}
    }
    @JavascriptInterface public boolean startCompass(double lat,double lon){
      if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return false;
      if(sensors==null)sensors=(android.hardware.SensorManager)getSystemService(SENSOR_SERVICE);
      boolean available=sensors!=null&&(sensors.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR)!=null||sensors.getDefaultSensor(android.hardware.Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)!=null||(sensors.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER)!=null&&sensors.getDefaultSensor(android.hardware.Sensor.TYPE_MAGNETIC_FIELD)!=null));
      if(!available)return false;magneticField=new android.hardware.GeomagneticField((float)lat,(float)lon,0,System.currentTimeMillis());compassWanted=true;runOnUiThread(()->beginSensors());return true;
    }
    @JavascriptInterface public void stopCompass(){compassWanted=false;runOnUiThread(()->pauseSensors());}
    @JavascriptInterface public boolean addDuaWidget(String title,String body){
      if(title==null||body==null||title.length()>200||body.length()>16000)return false;
      final android.appwidget.AppWidgetManager manager=android.appwidget.AppWidgetManager.getInstance(MainActivity.this);
      if(configureWidget>=0){final int id=configureWidget;DuaWidget.save(MainActivity.this,id,title,body);runOnUiThread(()->{DuaWidget.updateAll(MainActivity.this);setResult(RESULT_OK,new Intent().putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID,id));finish();});return true;}
      if(!manager.isRequestPinAppWidgetSupported())return false;
      final String token=UUID.randomUUID().toString();getSharedPreferences("screen-dua",0).edit().putString(token+":title",title).putString(token+":body",body).apply();
      runOnUiThread(()->{Intent result=new Intent(MainActivity.this,DuaWidgetPinned.class).setAction("app.shams.mobile.WIDGET_PIN").setData(Uri.parse("shams://widget/"+token)).putExtra("token",token);android.app.PendingIntent callback=android.app.PendingIntent.getBroadcast(MainActivity.this,0,result,android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_MUTABLE);manager.requestPinAppWidget(new android.content.ComponentName(MainActivity.this,DuaWidget.class),null,callback);});return true;
    }
    @JavascriptInterface public void saveDuaImage(String data,boolean wallpaper){
      if(data==null||!data.startsWith("data:image/png;base64,")||data.length()>12000000)return;
      try{byte[] image=android.util.Base64.decode(data.substring(22),android.util.Base64.DEFAULT);android.graphics.BitmapFactory.Options options=new android.graphics.BitmapFactory.Options();options.inJustDecodeBounds=true;android.graphics.BitmapFactory.decodeByteArray(image,0,image.length,options);if(options.outWidth!=1080||options.outHeight!=1920)return;
        if(wallpaper){File file=new File(getCacheDir(),"screen-dua.png");try(FileOutputStream output=new FileOutputStream(file)){output.write(image);}runOnUiThread(()->{Uri uri=Uri.parse("content://app.shams.mobile.dua/dua.png");try{Intent intent=android.app.WallpaperManager.getInstance(MainActivity.this).getCropAndSetWallpaperIntent(uri);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(intent);}catch(Exception e){try{Intent intent=new Intent(Intent.ACTION_ATTACH_DATA).setDataAndType(uri,"image/png").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(intent,"SHAMS"));}catch(Exception ignored){android.widget.Toast.makeText(MainActivity.this,"Save image and select it from Photos",android.widget.Toast.LENGTH_LONG).show();}}});}
        else{pendingDuaImage=image;runOnUiThread(()->{Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/png").putExtra(Intent.EXTRA_TITLE,"SHAMS-dua.png");try{startActivityForResult(create,9);}catch(Exception ignored){pendingDuaImage=null;}});}
      }catch(Exception ignored){}
    }
    @JavascriptInterface public void shareApp(String text,String url){if(!PUBLIC_URL.equals(url))return;final String message=(text==null?"SHAMS":text.substring(0,Math.min(text.length(),500)))+"\n"+PUBLIC_URL;runOnUiThread(()->{Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");share.putExtra(Intent.EXTRA_TEXT,message);startActivity(Intent.createChooser(share,"SHAMS"));});}
  }
  private void openExactPermission(){if(Build.VERSION.SDK_INT>=31&&!AdhanScheduler.exactAllowed(this))try{startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}
  @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results){super.onRequestPermissionsResult(code,permissions,results);if(code==16){openExactPermission();AdhanScheduler.rescheduleCached(this);}if(code==7&&geoCallback!=null){boolean allowed=false;for(int result:results)if(result==PackageManager.PERMISSION_GRANTED)allowed=true;geoCallback.invoke(geoOrigin,allowed,false);geoCallback=null;}}
  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==8&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}if(request==9){if(result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingDuaImage!=null){try(OutputStream output=getContentResolver().openOutputStream(data.getData())){output.write(pendingDuaImage);}catch(Exception ignored){}}pendingDuaImage=null;}}
  @Override protected void onSaveInstanceState(Bundle state){web.saveState(state);super.onSaveInstanceState(state);}
  @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
  @Override protected void onPause(){super.onPause();pauseSensors();web.evaluateJavascript("document.querySelectorAll('audio').forEach(function(a){a.pause()})",null);web.onPause();}
  @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();AdhanScheduler.rescheduleCached(this);AdhanScheduler.refreshAsync(this);if(compassWanted)beginSensors();}
  private void pauseSensors(){if(sensors!=null)sensors.unregisterListener(this);}
  private void beginSensors(){pauseSensors();gravity=null;magnetism=null;lastHeading=0;if(sensors==null)return;android.hardware.Sensor rotation=sensors.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR);if(rotation==null)rotation=sensors.getDefaultSensor(android.hardware.Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR);if(rotation!=null)sensors.registerListener(this,rotation,android.hardware.SensorManager.SENSOR_DELAY_GAME);else{android.hardware.Sensor a=sensors.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER),m=sensors.getDefaultSensor(android.hardware.Sensor.TYPE_MAGNETIC_FIELD);if(a!=null&&m!=null){sensors.registerListener(this,a,android.hardware.SensorManager.SENSOR_DELAY_GAME);sensors.registerListener(this,m,android.hardware.SensorManager.SENSOR_DELAY_GAME);}}}
  @Override public void onAccuracyChanged(android.hardware.Sensor sensor,int accuracy){compassAccuracy=accuracy;}
  @Override public void onSensorChanged(android.hardware.SensorEvent event){
    if(!compassWanted)return;float[] matrix=new float[9];int type=event.sensor.getType();
    if(type==android.hardware.Sensor.TYPE_ROTATION_VECTOR||type==android.hardware.Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)android.hardware.SensorManager.getRotationMatrixFromVector(matrix,event.values);
    else{if(type==android.hardware.Sensor.TYPE_ACCELEROMETER)gravity=event.values.clone();if(type==android.hardware.Sensor.TYPE_MAGNETIC_FIELD)magnetism=event.values.clone();if(gravity==null||magnetism==null||!android.hardware.SensorManager.getRotationMatrix(matrix,null,gravity,magnetism))return;}
    long now=android.os.SystemClock.elapsedRealtime();if(now-lastHeading<50)return;lastHeading=now;
    int rotation=getWindowManager().getDefaultDisplay().getRotation(),x=android.hardware.SensorManager.AXIS_X,y=android.hardware.SensorManager.AXIS_Y;
    if(rotation==android.view.Surface.ROTATION_90){x=android.hardware.SensorManager.AXIS_Y;y=android.hardware.SensorManager.AXIS_MINUS_X;}else if(rotation==android.view.Surface.ROTATION_180){x=android.hardware.SensorManager.AXIS_MINUS_X;y=android.hardware.SensorManager.AXIS_MINUS_Y;}else if(rotation==android.view.Surface.ROTATION_270){x=android.hardware.SensorManager.AXIS_MINUS_Y;y=android.hardware.SensorManager.AXIS_X;}
    float[] adjusted=new float[9],angles=new float[3];android.hardware.SensorManager.remapCoordinateSystem(matrix,x,y,adjusted);android.hardware.SensorManager.getOrientation(adjusted,angles);double heading=(Math.toDegrees(angles[0])+(magneticField==null?0:magneticField.getDeclination())+360)%360;
    if(web!=null&&trusted(Uri.parse(web.getUrl()==null?"":web.getUrl())))web.evaluateJavascript("if(typeof setCompassHeading==='function')setCompassHeading("+heading+","+compassAccuracy+")",null);
  }
  @Override protected void onDestroy(){compassWanted=false;pauseSensors();if(storeBilling!=null)storeBilling.close();if(web!=null){web.removeJavascriptInterface("ShamsAndroid");web.destroy();}super.onDestroy();}
}
