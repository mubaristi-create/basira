param([string]$AndroidSdk = "$env:LOCALAPPDATA/Android/Sdk",[string]$Jdk = 'C:/Program Files/Android/Android Studio/jbr')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$buildRoot = Join-Path $projectRoot 'android-build'
$privateRoot = Join-Path $projectRoot 'private-data'
$toolsRoot = Join-Path $AndroidSdk 'build-tools/35.0.0'
$platformJar = Join-Path $AndroidSdk 'platforms/android-36/android.jar'
$javaBin = Join-Path $Jdk 'bin/java.exe'
$javacBin = Join-Path $Jdk 'bin/javac.exe'
$keytoolBin = Join-Path $Jdk 'bin/keytool.exe'
function Invoke-Checked { param([string]$Program,[string[]]$Arguments) & $Program @Arguments; if ($LASTEXITCODE -ne 0) { throw "Build command failed: $Program" } }
New-Item -ItemType Directory -Force -Path $buildRoot,(Join-Path $buildRoot 'classes'),(Join-Path $buildRoot 'dex'),$privateRoot,(Join-Path $PSScriptRoot 'res/drawable') | Out-Null
Copy-Item -LiteralPath (Join-Path $projectRoot 'dist/icons/shams-app.png') -Destination (Join-Path $PSScriptRoot 'res/drawable/shams_icon.png') -Force
Invoke-Checked (Join-Path $toolsRoot 'aapt2.exe') @('compile','--dir',(Join-Path $PSScriptRoot 'res'),'-o',(Join-Path $buildRoot 'resources.zip'))
$generatedRoot = Join-Path $buildRoot 'generated'
New-Item -ItemType Directory -Force -Path $generatedRoot | Out-Null
Invoke-Checked (Join-Path $toolsRoot 'aapt2.exe') @('link','-o',(Join-Path $buildRoot 'resources-only.apk'),'--manifest',(Join-Path $PSScriptRoot 'AndroidManifest.xml'),'-I',$platformJar,(Join-Path $buildRoot 'resources.zip'),'--java',$generatedRoot,'--min-sdk-version','26','--target-sdk-version','35')
$compileBoot = $platformJar + [IO.Path]::PathSeparator + (Join-Path $toolsRoot 'core-lambda-stubs.jar')
Invoke-Checked $javacBin @('-encoding','UTF-8','-source','8','-target','8','-bootclasspath',$compileBoot,'-d',(Join-Path $buildRoot 'classes'),(Join-Path $PSScriptRoot 'src/app/shams/mobile/MainActivity.java'),(Join-Path $PSScriptRoot 'src/app/shams/mobile/DuaWidget.java'),(Join-Path $PSScriptRoot 'src/app/shams/mobile/DuaWidgetPinned.java'),(Join-Path $PSScriptRoot 'src/app/shams/mobile/DuaImageProvider.java'),(Join-Path $generatedRoot 'app/shams/mobile/R.java'))
$classFiles = @(Get-ChildItem -LiteralPath (Join-Path $buildRoot 'classes') -Filter '*.class' -Recurse | ForEach-Object FullName)
Invoke-Checked $javaBin (@('-cp',(Join-Path $toolsRoot 'lib/d8.jar'),'com.android.tools.r8.D8','--lib',$platformJar,'--min-api','26','--output',(Join-Path $buildRoot 'dex')) + $classFiles)
$unsignedApk = Join-Path $buildRoot 'shams-unsigned.apk'
$assetRoot = Join-Path $buildRoot 'assets'
New-Item -ItemType Directory -Force -Path $assetRoot | Out-Null
Get-ChildItem -LiteralPath (Join-Path $projectRoot 'dist') -File | Where-Object Extension -In '.html','.js','.css','.webmanifest' | Copy-Item -Destination $assetRoot -Force
foreach ($assetFolder in @('icons','audio')) { Copy-Item -LiteralPath (Join-Path $projectRoot "dist/$assetFolder") -Destination $assetRoot -Recurse -Force }
Invoke-Checked (Join-Path $toolsRoot 'aapt2.exe') @('link','-o',$unsignedApk,'--manifest',(Join-Path $PSScriptRoot 'AndroidManifest.xml'),'-I',$platformJar,(Join-Path $buildRoot 'resources.zip'),'-A',$assetRoot,'--min-sdk-version','26','--target-sdk-version','35')
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::Open($unsignedApk,[System.IO.Compression.ZipArchiveMode]::Update)
try { [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $buildRoot 'dex/classes.dex'),'classes.dex') | Out-Null } finally { $archive.Dispose() }
$alignedApk = Join-Path $buildRoot 'shams-aligned.apk'
Invoke-Checked (Join-Path $toolsRoot 'zipalign.exe') @('-f','-p','4',$unsignedApk,$alignedApk)
$keystore = Join-Path $privateRoot 'android-signing.p12'
$passwordFile = Join-Path $privateRoot 'android-signing-password.txt'
if (!(Test-Path -LiteralPath $passwordFile)) { $secretBytes = [byte[]]::new(32); [System.Security.Cryptography.RandomNumberGenerator]::Fill($secretBytes); [IO.File]::WriteAllText($passwordFile,[Convert]::ToBase64String($secretBytes)) }
$env:SHAMS_APK_STORE_PASS = [IO.File]::ReadAllText($passwordFile)
try {
 if (!(Test-Path -LiteralPath $keystore)) { Invoke-Checked $keytoolBin @('-genkeypair','-keystore',$keystore,'-alias','shams','-keyalg','RSA','-keysize','3072','-validity','3650','-storetype','PKCS12','-storepass:env','SHAMS_APK_STORE_PASS','-keypass:env','SHAMS_APK_STORE_PASS','-dname','CN=SHAMS Development,O=SHAMS,C=AZ') }
 $apk = Join-Path (Split-Path $projectRoot -Parent) 'SHAMS-1.4.0.apk'
 Invoke-Checked $javaBin @('-jar',(Join-Path $toolsRoot 'lib/apksigner.jar'),'sign','--ks',$keystore,'--ks-key-alias','shams','--ks-pass','env:SHAMS_APK_STORE_PASS','--out',$apk,$alignedApk)
 Invoke-Checked $javaBin @('-jar',(Join-Path $toolsRoot 'lib/apksigner.jar'),'verify','--verbose',$apk)
 Write-Output "APK: $apk"
} finally { Remove-Item Env:SHAMS_APK_STORE_PASS }
